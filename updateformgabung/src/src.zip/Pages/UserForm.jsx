import React, { Component } from 'react';
import FormDataAgunan from '../Components/FormDataAgunan';
import Confirm from '../Components/Confirm';
import Success from '../Components/Success';
import FormDataPemohon from '../Components/FormDataPemohon'

export class UserForm extends Component {
  state = {
    step: 1,
    jenisAgunan: '',
    luasTanah: '',
    luasBangunan: '',
    statusKepemilikan: '',
    kondisiBangunan: '',
    statusAgunan: '',
    atasNamaSertifikat: '',
    nomorSertifikat: '',
    nomorSPRDeveloper: '',
    alamatPropertiAngunan: '',
    provinsiAgunan: '',
    kabupatenKotaAgunan: '',
    kecamatanAgunan: '',
    kelurahanAgunan: '',
    rtRwAgunan: '',
    kodePosAngunan: '',
    //page3
    namaLengkap: '',
    tempatLahir: '',
    tanggalLahir: '',
    noKTP: '',
    noNPWP: '',
    namaGadisIbuKandung: '',
    statusPerkawinan: '',
    pendidikanTerakhir: '',
    statusTempatTinggal: '',
    alamatKTP: '',
    provinsiKTP: '',
    kotaKabupatenKTP: '',
    kelurahanKTP: '',
    kecamatanKTP: '',
    kodeposKTP: '',
    alamatSaatIni: '',
    provinsiSaatIni: '',
    kotaKabupatenSaatIni: '',
    kelurahanSaatIni: '',
    kecamatanSaatIni: '',
    kodeposSaatIni: '',
    alamatSuratMenyurat: '',
    noTeleponRumah: '',
    email: '',
    noHP: ''
  };


  // Proceed to next step
  nextStep = () => {
    const { step } = this.state;
    this.setState({
      step: step + 1
    });
  };

  // Go back to prev step
  prevStep = () => {
    const { step } = this.state;
    this.setState({
      step: step - 1
    });
  };

  // Handle fields change
  handleChange = input => e => {
    this.setState({ [input]: e.target.value });
  };

  render() {
    const { step } = this.state;
    const { jenisAgunan, luasTanah, luasBangunan, statusKepemilikan, kondisiBangunan, statusAgunan, atasNamaSertifikat, nomorSertifikat, nomorSPRDeveloper, alamatPropertiAngunan, provinsiAgunan, kabupatenKotaAgunan, kecamatanAgunan, kelurahanAgunan, rtRwAgunan, kodePosAngunan,

    namaLengkap, tempatLahir, tanggalLahir, noKTP, noNPWP, namaGadisIbuKandung, statusPerkawinan, pendidikanTerakhir, statusTempatTinggal, alamatKTP, provinsiKTP, kotaKabupatenKTP, kelurahanKTP, kecamatanKTP, kodeposKTP, alamatSaatIni, provinsiSaatIni, kotaKabupatenSaatIni, kelurahanSaatIni, kecamatanSaatIni, kodeposSaatIni, alamatSuratMenyurat, noTeleponRumah, email, noHP } = this.state;

    const values = { jenisAgunan, luasTanah, luasBangunan, statusKepemilikan, kondisiBangunan, statusAgunan, atasNamaSertifikat, nomorSertifikat, nomorSPRDeveloper, alamatPropertiAngunan, provinsiAgunan, kabupatenKotaAgunan, kecamatanAgunan, kelurahanAgunan, rtRwAgunan, kodePosAngunan,
    
    namaLengkap, tempatLahir, tanggalLahir, noKTP, noNPWP, namaGadisIbuKandung, statusPerkawinan, pendidikanTerakhir, statusTempatTinggal, alamatKTP, provinsiKTP, kotaKabupatenKTP, kelurahanKTP, kecamatanKTP, kodeposKTP, alamatSaatIni, provinsiSaatIni, kotaKabupatenSaatIni, kelurahanSaatIni, kecamatanSaatIni, kodeposSaatIni, alamatSuratMenyurat, noTeleponRumah, email, noHP};

    switch (step) {
      case 1:
        return (
          <FormDataAgunan
            nextStep={this.nextStep}
            handleChange={this.handleChange}
            values={values}
          />
        );
      case 2:
        return (
          <FormDataPemohon
            nextStep={this.nextStep}
            prevStep={this.prevStep}
            handleChange={this.handleChange}
            values={values}
          />
        );
      case 3:
        return (
          <Confirm
            nextStep={this.nextStep}
            prevStep={this.prevStep}
            values={values}
          />
        );
      case 4:
        return <Success />;
      default:
        (console.log('Terimakasih'))
    }
  }
}

export default UserForm;

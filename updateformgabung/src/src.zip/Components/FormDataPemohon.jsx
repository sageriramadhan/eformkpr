import React, { Component } from 'react';
import { ThemeProvider as MuiThemeProvider } from '@material-ui/core/styles';
import { Dialog, AppBar, TextField, MenuItem, Button, FormControl, FormLabel, Grid } from '@material-ui/core';
import { DatePicker } from "@material-ui/pickers";
import '../Styles/formStyle.css'
import { withStyles, createStyles } from "@material-ui/core/styles";

const styles = theme => createStyles({
  root: {
    "& .MuiFormLabel-root": {
      // color: "red"
    }
  },
  label: {
    color: "#490E73",
    fontSize: "12px",
    fontWeight: 600,
    fontFamily: "Open Sans"
  },
  formControl: {
    left: 150,
    right: 150
  },
  text: {
    width: "641px"
  }
});

export class FormDataPemohon extends Component {
  continue = e => {
    e.preventDefault();
    this.props.nextStep();
  };

  back = e => {
    e.preventDefault();
    this.props.prevStep();
  };

  render() {
    const { values, handleChange, classes } = this.props;

    return (
      <div className="mainPage">
        <div className="mainForm">
          <p className="judul">Data Pemohon</p>
          <br />
          <br />
          <AppBar title="Masukkan Data Pengguna" />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Nama Lengkap Tanpa Singkatan dan Tanpa Gelar</FormLabel>
            <TextField
              className={classes.text}
              placeholder="Masukkan Nama Lengkap Tanpa Singkatan dan Tanpa Gelar"
              onChange={handleChange('namaLengkap')}
              defaultValue={values.namaLengkap}
              margin="normal"
            />
          </FormControl>
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Tempat / Tanggal Lahir </FormLabel>
            <TextField
              className={classes.text}
              placeholder="Masukkan Tempat"
              onChange={handleChange('tempatLahir')}
              defaultValue={values.tempatLahir}
              margin="normal"
            />
            <TextField
              className={classes.text}
              placeholder="Tanggal"
              onChange={handleChange('tanggalLahir')}
              defaultValue={values.tanggalLahir}
              margin="normal"
              fullWidth
            />
            {/* <DatePicker
              variant="inline"
              openTo="year"
              views={["year", "month"]}
              label="Year and Month"
              helperText="Start from year selection"
              value={selectedDate}
              onChange={handleDateChange}
            /> */}
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Nomor KTP</FormLabel>
            <TextField
              className={classes.text}
              placeholder="Masukkan 16 Digit Nomor KTP"
              onChange={handleChange('noKTP')}
              defaultValue={values.noKTP}
              margin="normal"
            />
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Nomor NPWP</FormLabel>
            <TextField
              className={classes.text}
              placeholder="Masukkan Nomor NPWP"
              label="Nomor NPWP"
              onChange={handleChange('noNPWP')}
              defaultValue={values.noNPWP}
              margin="normal"
              fullWidth
            />
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Nomor NPWP</FormLabel>
            <TextField
              className={classes.text}
              placeholder="Masukkan Nama Gadis Ibu Kandung"
              label="Nama Gadis Ibu Kandung"
              onChange={handleChange('namaGadisIbuKandung')}
              defaultValue={values.namaGadisIbuKandung}
              margin="normal"
            />
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Status Perkawinan</FormLabel>
            <TextField
              label={values.statusPerkawinan === "" ? "Pilih Status Perkawinan" : ""}
              className={classes.text}
              InputLabelProps={{ shrink: false }}
              onChange={handleChange('statusPerkawinan')}
              defaultValue={values.statusPerkawinan}
              margin="normal"
              fullWidth
              select>
              <MenuItem value="Single">Single</MenuItem>
              <MenuItem value="Menikah">Menikah</MenuItem>
            </TextField>
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Pendidikan Terakhir</FormLabel>
            <TextField
              label={values.pendidikanTerakhir === "" ? "Pilih Pendidikan Terakhir" : ""}
              className={classes.text}
              InputLabelProps={{ shrink: false }}
              onChange={handleChange('pendidikanTerakhir')}
              defaultValue={values.pendidikanTerakhir}
              margin="normal"
              fullWidth
              select>
              <MenuItem value="SD">SD</MenuItem>
              <MenuItem value="SMP">SMP</MenuItem>
              <MenuItem value="SMA">SMA</MenuItem>
              <MenuItem value="S1">S1</MenuItem>
              <MenuItem value="S2">S2</MenuItem>
              <MenuItem value="S3">S3</MenuItem>
            </TextField>
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Status Tempat Tinggal</FormLabel>
            <TextField
              label={values.statusTempatTinggal === "" ? "Pilih Status Tempat Tinggal" : ""}
              className={classes.text}
              InputLabelProps={{ shrink: false }}
              onChange={handleChange('statusTempatTinggal')}
              defaultValue={values.statusTempatTinggal}
              margin="normal"
              fullWidth
              select>
              <MenuItem value="Milik Orangtua">Milik Orangtua</MenuItem>
              <MenuItem value="Milik Sendiri">Milik Sendiri</MenuItem>
              <MenuItem value="Kosan">Kosan</MenuItem>
              <MenuItem value="Sewa/Kontrak">Sewa/Kontrak</MenuItem>
            </TextField>
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Alamat sesuai KTP</FormLabel>
            <TextField
              className={classes.text}
              placeholder="Pilih Provinsi"
              onChange={handleChange('provinsiKTP')}
              defaultValue={values.provinsiKTP}
              margin="normal"
              fullWidth
            />
            <TextField
              className={classes.text}
              placeholder="Pilih Kabupaten/Kota"
              onChange={handleChange('kotaKabupatenKTP')}
              defaultValue={values.kotaKabupatenKTP}
              margin="normal"
              fullWidth
            />
            <TextField
              className={classes.text}
              placeholder="Pilih Kecamatan"
              onChange={handleChange('kecamatanKTP')}
              defaultValue={values.kecamatanKTP}
              margin="normal"
              fullWidth
            />
            <TextField
              className={classes.text}
              placeholder="Pilih Kelurahan"
              onChange={handleChange('kelurahanKTP')}
              defaultValue={values.kelurahanKTP}
              margin="normal"
              fullWidth
            />
            <TextField
              className={classes.text}
              placeholder="Masukkan Detail Alamat (Nama Jalan, No. Rumah, Blok, RT/RW"
              onChange={handleChange('alamatKTP')}
              defaultValue={values.alamatKTP}
              margin="normal"
              fullWidth
            />
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Alamat Tempat Tinggal Saat Ini</FormLabel>
            <TextField
              className={classes.text}
              placeholder="Pilih Provinsi"
              onChange={handleChange('provinsiSaatIni')}
              defaultValue={values.provinsiSaatIni}
              margin="normal"
              fullWidth
            />
            <TextField
              className={classes.text}
              placeholder="Pilih Kabupaten/Kota"
              onChange={handleChange('kotaKabupatenSaatIni')}
              defaultValue={values.kotaKabupatenSaatIni}
              margin="normal"
              fullWidth
            />
            <TextField
              className={classes.text}
              placeholder="Pilih Kecamatan"
              onChange={handleChange('kecamatanSaatIni')}
              defaultValue={values.kecamatanSaatIni}
              margin="normal"
              fullWidth
            />
            <TextField
              className={classes.text}
              placeholder="Pilih Kelurahan"
              onChange={handleChange('kelurahanSaatIni')}
              defaultValue={values.kelurahanSaatIni}
              margin="normal"
              fullWidth
            />
            <TextField
              className={classes.text}
              placeholder="Masukkan Detail Alamat (Nama Jalan, No. Rumah, Blok, RT/RW"
              onChange={handleChange('alamatSaatIni')}
              defaultValue={values.alamatSaatIni}
              margin="normal"
              fullWidth
            />
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Alamat Surat Menyurat</FormLabel>
            <TextField
              label={values.alamatSuratMenyurat === "" ? "Pilih Alamat Surat Menyurat" : ""}
              InputLabelProps={{ shrink: false }}
              className={classes.text}
              onChange={handleChange('alamatSuratMenyurat')}
              defaultValue={values.alamatSuratMenyurat}
              margin="normal"
              fullWidth
              select>
              <MenuItem value="Alamat KTP">Alamat KTP</MenuItem>
              <MenuItem value="Alamat Saat Ini">Alamat Saat Ini</MenuItem>
            </TextField>
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>No. Telepon Rumah</FormLabel>
            <TextField
              className={classes.text}
              placeholder="+62 | xxx-xxxx-xxxx"
              onChange={handleChange('noTeleponRumah')}
              defaultValue={values.noTeleponRumah}
              margin="normal"
              fullWidth
            />
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>Alamat Email</FormLabel>
            <TextField
              className={classes.text}
              placeholder="Masukkan Alamat Email Aktif"
              onChange={handleChange('email')}
              defaultValue={values.email}
              margin="normal"
              fullWidth
            />
          </FormControl>
          <br />
          <FormControl className={classes.formControl}>
            <FormLabel className={classes.label}>No. Handphone</FormLabel>
            <TextField
              className={classes.text}
              placeholder="+62 | xxx-xxxx-xxxx"
              onChange={handleChange('noHP')}
              defaultValue={values.noHP}
              margin="normal"
              fullWidth
            />
          </FormControl>
          <br />
          <div className="footer">
            <Button
              className="button1"
              variant="contained"
              onClick={this.back}
            >Periksa Kembali</Button>

            <Button
              className="button2"
              variant="contained"
              onClick={this.continue}
            >Lanjut</Button>
          </div>

        </div>
      </div>
    );
  }
}

export default withStyles(styles)(FormDataPemohon);
